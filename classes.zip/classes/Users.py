class User:
    def __init__(self, fname, lname, height, weight):
        self.logging_status = 'Falied'
        self.firstname = fname
        self.lastname = lname
        self.height = height
        self.weight = weight

        



   


    